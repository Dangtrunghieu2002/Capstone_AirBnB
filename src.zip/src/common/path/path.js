export const path = {
  homePage: "/",
  pageNotFound: "*",
  listRoomPage: "/list-room",
  roomDetail: "/room-detail",
  inforUser: "/infor-user",
  signIn: "/sign-in",
  signUp:"/sign-up",
};
