Thư mục components chứa các components tái sử dụng trong dự án hoặc các cấu trúc layout cần chia nhỏ. Lưu ý là nếu components đó không được tái sử dụng nhiều thì không nên chia components
